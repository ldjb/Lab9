public class Square extends Rectangle{

	public Square(double var0) {
		super(var0, var0);
	}

}